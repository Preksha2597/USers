import { Component, OnInit } from '@angular/core';
import { Users } from '../user';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

 
  user:Users[];
  u:Users=new Users(0,null,null,null);
  
  public constructor(private userService:UsersService){}
  ngOnInit() {
  }
  public getUsers():void{
      this.userService.getUsers().subscribe(data=>{this.user=data});
  }
  public getUser():void{
      this.userService.getUser(this.u.id).subscribe(data=>{this.u=data});
  }
  public addUser():void{
      this.userService.addUser(this.u).subscribe();
  }
  public modUser():void{
      this.userService.modUser(this.u).subscribe();
  }
  public delUser():void{
      this.userService.delUser(this.u.id).subscribe();
  }
  
  }

