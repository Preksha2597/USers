import { Injectable } from '@angular/core';
import { Users } from './user';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  public constructor(private httpClient:HttpClient){}
public getUsers():Observable<Users[]>
{
return this.httpClient.get<Users[]>('http://localhost:8091/all');
}

public getUser(id):Observable<Users>
{
    return this.httpClient.get<Users>('http://localhost:8091/'+id);
}
public addUser(user):any
{
    return this.httpClient.post('http://localhost:8091/',user); 
}
public modUser(user):any
{
   return  this.httpClient.put('http://localhost:8091/',user); 

}
public delUser(id):any
{
   return this.httpClient.delete('http://localhost:8091/'+id); 
}
}
