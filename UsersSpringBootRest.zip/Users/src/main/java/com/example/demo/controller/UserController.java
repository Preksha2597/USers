package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Users;
import com.example.demo.service.UsersServiceImpl;

@CrossOrigin("http://localhost:4200")
@RestController
public class UserController {

	@Autowired
	UsersServiceImpl service;

	public void setService(UsersServiceImpl service) {
		this.service = service;
	}
	@GetMapping("/{id}")
	public Users getUser(@PathVariable("id")int id) {
		return service.getUser(id);
		
	}
	
	
	 @GetMapping(value="/all", produces="application/json")
	 public Iterable<Users> getUsers()
	 {
		 return service.getUsers();
	 }
@PostMapping 
public void addUser(@RequestBody()Users user)
{
	service.addUser(user);
}

@PutMapping void modifyUser(@RequestBody()Users user)
{
	service.addUser(user);
}
@DeleteMapping("/{id}")
public void deleteUser(@PathVariable("id")int id)
{
service.deleteUser(id);
}


}
