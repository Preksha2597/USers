package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Users;

@Service
public interface UsersService {
	public Users getUser(int id);
	public Iterable<Users>getUsers();
	public void addUser (Users user);
	public void modifyUser (Users user);
	public void deleteUser(int id);
}
