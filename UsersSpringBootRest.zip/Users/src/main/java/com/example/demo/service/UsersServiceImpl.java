package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UsersDao;
import com.example.demo.entity.Users;
@Service
public class UsersServiceImpl implements UsersService {

	
	@Autowired
	UsersDao userdao;
	
	
	public UsersDao getUserdao() {
		return userdao;
	}

	public void setUserdao(UsersDao userdao) {
		this.userdao = userdao;
	}

	@Override
	public Users getUser(int id) {
		// TODO Auto-generated method stub
		return userdao.findById(id).get();
	}

	@Override
	public Iterable<Users> getUsers() {
		// TODO Auto-generated method stub
		return userdao.findAll();
	}

	@Override
	public void addUser(Users user) {
		// TODO Auto-generated method stub
		userdao.save(user);
	}

	@Override
	public void modifyUser(Users user) {
		// TODO Auto-generated method stub
		userdao.save(user);
	}

	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		userdao.deleteById(id);
	}

}
